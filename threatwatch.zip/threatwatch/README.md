# ThreatWatch

A threat-alert dashboard built with React (Vite) and Recharts. Alerts come from a hardcoded JSON file, so no backend is needed.

**Live demo:** _add your Vercel link_  
**Screenshots:** _add desktop, mobile and dark mode images to `/screenshots`_

## Features
- Alert list with search and severity/status filters
- Summary cards, plus charts of alerts by severity and over time
- Detail drawer with a "Mark as resolved" action (updates every count and chart)
- Responsive layout and a persisted dark mode toggle

## Architecture
- **Container:** `Dashboard` holds all state (alerts, filters, selection, theme) and derives filtered lists and chart data with `useMemo`.
- **Presentational:** `AlertCard`, `SeverityBadge`, `FilterBar`, `SummaryCards`, `Charts` and `AlertDetail` receive props and callbacks only.

## Run locally
```bash
npm install
npm run dev
```

## Deploy
Push to GitHub, import the repo in Vercel and accept the Vite defaults.

## Next steps
Node/Express + MongoDB API for alerts, auth, and real-time updates.
