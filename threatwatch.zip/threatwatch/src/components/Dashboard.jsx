import { useState, useMemo, useEffect } from "react";
import initialAlerts from "../data/alerts.json";
import FilterBar from "./FilterBar.jsx";
import AlertCard from "./AlertCard.jsx";
import SummaryCards from "./SummaryCards.jsx";
import Charts from "./Charts.jsx";
import AlertDetail from "./AlertDetail.jsx";

const ORDER = ["critical", "high", "medium", "low"];

// Container component: owns all state; children are presentational.
export default function Dashboard() {
  const [alerts, setAlerts] = useState(initialAlerts);
  const [filters, setFilters] = useState({ query: "", severity: "all", status: "all" });
  const [selectedId, setSelectedId] = useState(null);
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem("tw-theme") || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"); }
    catch { return "light"; }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem("tw-theme", theme); } catch { /* ignore */ }
  }, [theme]);

  const visible = useMemo(() => {
    const q = filters.query.trim().toLowerCase();
    return alerts
      .filter((a) => (filters.severity === "all" || a.severity === filters.severity) && (filters.status === "all" || a.status === filters.status))
      .filter((a) => !q || [a.title, a.source, a.id].some((f) => f.toLowerCase().includes(q)))
      .sort((a, b) => b.date.localeCompare(a.date) || ORDER.indexOf(a.severity) - ORDER.indexOf(b.severity));
  }, [alerts, filters]);

  const bySeverity = useMemo(() => ORDER.map((name) => ({ name, count: alerts.filter((a) => a.severity === name).length })), [alerts]);
  const overTime = useMemo(() => {
    const map = {};
    alerts.forEach((a) => { map[a.date] = (map[a.date] || 0) + 1; });
    return Object.entries(map).sort().map(([date, count]) => ({ date: date.slice(5), count }));
  }, [alerts]);

  const resolve = (id) => setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, status: "resolved" } : a)));
  const selected = alerts.find((a) => a.id === selectedId) || null;

  return (
    <div className="app">
      <header>
        <h1>ThreatWatch</h1>
        <button className="ghost" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Toggle dark mode">
          {theme === "dark" ? "Light mode" : "Dark mode"}
        </button>
      </header>
      <SummaryCards alerts={alerts} />
      <Charts bySeverity={bySeverity} overTime={overTime} />
      <section className="panel">
        <h2>Alerts <span className="muted">({visible.length})</span></h2>
        <FilterBar filters={filters} onChange={setFilters} />
        {visible.length === 0 ? (
          <p className="muted empty">No alerts match these filters. Clear the search or pick "All".</p>
        ) : (
          <ul className="list">
            {visible.map((a) => <AlertCard key={a.id} alert={a} selected={a.id === selectedId} onSelect={setSelectedId} />)}
          </ul>
        )}
      </section>
      <AlertDetail alert={selected} onClose={() => setSelectedId(null)} onResolve={resolve} />
    </div>
  );
}
