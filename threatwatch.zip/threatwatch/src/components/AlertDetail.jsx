import SeverityBadge from "./SeverityBadge.jsx";

export default function AlertDetail({ alert, onClose, onResolve }) {
  if (!alert) return null;
  return (
    <div className="overlay" onClick={onClose}>
      <aside className="detail" role="dialog" aria-modal="true" aria-label="Alert details" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose} aria-label="Close details">×</button>
        <div><SeverityBadge level={alert.severity} /></div>
        <h2>{alert.title}</h2>
        <p>{alert.description}</p>
        <dl>
          <dt>ID</dt><dd>{alert.id}</dd>
          <dt>Source</dt><dd>{alert.source}</dd>
          <dt>Detected</dt><dd>{alert.date}</dd>
          <dt>Status</dt><dd>{alert.status}</dd>
        </dl>
        <button className="primary" disabled={alert.status === "resolved"} onClick={() => onResolve(alert.id)}>
          {alert.status === "resolved" ? "Resolved" : "Mark as resolved"}
        </button>
      </aside>
    </div>
  );
}
