import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, LineChart, Line, CartesianGrid } from "recharts";

const SEV_COLORS = { critical: "#d6336c", high: "#f08c00", medium: "#3b82c4", low: "#6b8f71" };

export default function Charts({ bySeverity, overTime }) {
  return (
    <section className="charts">
      <div className="panel">
        <h2>Alerts by severity</h2>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={bySeverity}>
            <XAxis dataKey="name" stroke="currentColor" fontSize={12} />
            <YAxis allowDecimals={false} stroke="currentColor" fontSize={12} width={28} />
            <Tooltip />
            <Bar dataKey="count" radius={[3, 3, 0, 0]}>
              {bySeverity.map((d) => <Cell key={d.name} fill={SEV_COLORS[d.name]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="panel">
        <h2>Alerts over time</h2>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={overTime}>
            <CartesianGrid strokeOpacity={0.15} vertical={false} />
            <XAxis dataKey="date" stroke="currentColor" fontSize={12} />
            <YAxis allowDecimals={false} stroke="currentColor" fontSize={12} width={28} />
            <Tooltip />
            <Line type="monotone" dataKey="count" stroke="#0e9aa7" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
