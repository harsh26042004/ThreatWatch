export default function SummaryCards({ alerts }) {
  const count = (fn) => alerts.filter(fn).length;
  const items = [
    ["Total alerts", alerts.length],
    ["Critical (unresolved)", count((a) => a.severity === "critical" && a.status !== "resolved")],
    ["Open", count((a) => a.status === "open")],
    ["Resolved", count((a) => a.status === "resolved")],
  ];
  return (
    <section className="summary">
      {items.map(([label, value]) => (
        <div className="stat" key={label}><span className="stat-value">{value}</span><span className="muted">{label}</span></div>
      ))}
    </section>
  );
}
