const SEVERITIES = ["all", "critical", "high", "medium", "low"];
const STATUSES = ["all", "open", "investigating", "resolved"];

export default function FilterBar({ filters, onChange }) {
  const set = (key) => (e) => onChange({ ...filters, [key]: e.target.value });
  return (
    <div className="filters">
      <input type="search" placeholder="Search title, source or ID" value={filters.query} onChange={set("query")} aria-label="Search alerts" />
      <select value={filters.severity} onChange={set("severity")} aria-label="Filter by severity">
        {SEVERITIES.map((s) => <option key={s} value={s}>{s === "all" ? "All severities" : s}</option>)}
      </select>
      <select value={filters.status} onChange={set("status")} aria-label="Filter by status">
        {STATUSES.map((s) => <option key={s} value={s}>{s === "all" ? "All statuses" : s}</option>)}
      </select>
    </div>
  );
}
