import SeverityBadge from "./SeverityBadge.jsx";

export default function AlertCard({ alert, selected, onSelect }) {
  return (
    <li>
      <button className={`alert sev-bar-${alert.severity} ${selected ? "selected" : ""}`} onClick={() => onSelect(alert.id)}>
        <div className="alert-top">
          <SeverityBadge level={alert.severity} />
          <span className={`status status-${alert.status}`}>{alert.status}</span>
        </div>
        <strong>{alert.title}</strong>
        <span className="muted">{alert.source} · {alert.date}</span>
      </button>
    </li>
  );
}
